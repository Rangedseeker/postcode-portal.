
# Public Postcode Portal (Static)

This is a single-page site you can host anywhere (Netlify, Vercel, GitHub Pages).

## Files
- `index.html` – the app (country/postcode selectors + 5-number sum)
- `postcodes_uk.json` – UK data generated from your Excel

## Run locally
Just open `index.html` in your browser. Some browsers block `fetch()` from the file system; if that happens:

```bash
# Start a tiny static server (Python 3)
python -m http.server 8080
# then open http://localhost:8080/portal/
```

## Deploy to Netlify (recommended)
1. Create a new GitHub repo and add both files in the `portal/` folder.
2. In Netlify, click **New site from Git** and select your repo.
3. Build settings: *none* (static). Publish directory: `portal`.
4. Deploy. You'll get a public `https://<name>.netlify.app` URL.

## Deploy to Vercel
1. Import your GitHub repo into Vercel.
2. Framework preset: **Other**. Output/public dir: `portal`.
3. Deploy to get `https://<name>.vercel.app`.

## Deploy to GitHub Pages
1. In your repo, go to **Settings → Pages**.
2. Select branch `main`, folder `/root` (or `/docs` if you move files there).
3. Visit `https://<your-username>.github.io/<repo-name>/portal/`.

## Add Netherlands data later
- Prepare a `postcodes_nl.json` as an array of strings or objects.
- In `index.html`, update the `Netherlands` branch in `updatePostcodeList()` to fetch and use it.

